l1=[50,60,70,80]
l2=[10,20,30,40]
for i,j in zip(l1,l2[::-1]):
     print(i,j)
