lst=[]
for i in range(3):
    t=()
    for j in range(2):
        e=int(input())
        t+=e,
        lst.append(t)
print(lst)
        
