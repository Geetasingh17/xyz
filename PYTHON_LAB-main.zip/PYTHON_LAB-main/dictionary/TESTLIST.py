l=['hello ','dear ']
l1=['sir','mam']
l2=[]
for i in range(2):
    l2.append(l[i]+l1[i])
print(l2)