a = 1 > 0

if (1 / 0 == 0) or a:
    print('ok')
else:
    print('nok')