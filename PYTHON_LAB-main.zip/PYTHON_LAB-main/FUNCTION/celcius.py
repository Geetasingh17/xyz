from random import random


out=random.random()
print(str(out)[-6:])