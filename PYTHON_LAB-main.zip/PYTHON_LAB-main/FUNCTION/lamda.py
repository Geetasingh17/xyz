n=int(input("enter no"))
for i in range (1,10):
     ans=lambda i:n*i
     print(ans(i))