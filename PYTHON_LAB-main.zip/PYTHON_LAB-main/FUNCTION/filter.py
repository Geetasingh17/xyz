lst=['gandu','andu','landu']
lst.sort(key=lambda x:x[-1])
print(lst)