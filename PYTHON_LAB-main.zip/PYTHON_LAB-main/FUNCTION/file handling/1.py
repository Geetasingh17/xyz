f =open('abc','w')

f.write("something")