#include<stdio.h>
int main()
{
  char i='a';
printf("alphabhet a to z");
while(i<='z')
{
    
    printf("%c\n",i);
    i++;
}
}
