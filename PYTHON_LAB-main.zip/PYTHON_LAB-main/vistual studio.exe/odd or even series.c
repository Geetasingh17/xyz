#include<stdio.h>
int main()
{
    int a=1;
   while(a<=500)
{
    if(a%2==0)
    {
    printf("%d even\n",a);
    }
    else if(a!=0)
    {
    printf("%d odd\n",a);

}
a++;

}
}



