	 #include<stdio.h>
void main()
{
int a=2, b=10, k, c;
k=! ((a<2) && b>2));
printf(“%d\n”,k);
c= (b<a || b>a);
printf(“%d”,c);
}
