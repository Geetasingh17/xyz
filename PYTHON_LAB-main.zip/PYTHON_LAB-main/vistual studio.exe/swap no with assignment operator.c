#include<stdio.h>
int main()
{  
    int a,b,c;
    printf("enter the value of first no  ");
    scanf("%d",&a);
    printf("enter the value of second no ");
    scanf("%d",&b);
    c=b;
    printf("%d is first",c);
    b=a;
    printf("%d is second",b);
    
}