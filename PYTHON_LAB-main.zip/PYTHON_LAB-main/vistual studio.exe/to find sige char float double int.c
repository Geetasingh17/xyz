#include<stdio.h>
int main()
{  
    int integerdatatype;
    char chardatatype;
    float floatdatatype;
    double doubledatatype;

    printf("intger sige -%zu\n",sizeof(integerdatatype));
    printf("character sige- %zu\n",sizeof(chardatatype));
    printf("float sige-%zu\n",sizeof(floatdatatype));
    printf("double sige-%zu",sizeof(doubledatatype));
    
    
}