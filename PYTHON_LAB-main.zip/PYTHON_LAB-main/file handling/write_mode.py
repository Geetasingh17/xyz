# Python code to create a file
file = open('a.txt','w')
file.write("This is the write command")
file.write("It allows us to write in a particular file")
file.close()
