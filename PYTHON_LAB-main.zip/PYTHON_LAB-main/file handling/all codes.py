'''f=open('new.txt','a')
str=input()
f.write(str)
f.close()
str=f.newline()
print(str)'''
'''f=open('new.txt','a+')
f.write(str)
f.seek(0,2)
print(str)
f.close()'''

'''f=open('new.txt','a+')
str= f.read()
str1=f.readlines()
xl=line(str1)
'''for i in str:
 x=i.split()
 print(count)'''
