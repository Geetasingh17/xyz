# Python code to illustrate append() mode
file = open('a.txt','a')
file.write("This will add this line")
file.close()
