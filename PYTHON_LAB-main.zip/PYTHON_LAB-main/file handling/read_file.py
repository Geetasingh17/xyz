file = open('a.txt', 'r')
for each in file:
	print (each)
